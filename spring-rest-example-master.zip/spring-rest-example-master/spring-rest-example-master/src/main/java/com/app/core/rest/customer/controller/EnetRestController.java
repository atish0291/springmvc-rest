package com.app.core.rest.customer.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.core.rest.customer.model.Acknowledgement;
import com.app.core.rest.customer.model.Address;
import com.app.core.rest.customer.model.KdrDocMaster;
import com.app.core.rest.customer.model.NameChange;
import com.app.core.rest.customer.model.NameChangeResponse;
import com.app.core.rest.customer.model.PanUpdate;
import com.app.core.rest.customer.service.EnetService;

import javax.inject.Inject;
import javax.inject.Named;



@RestController
@RequestMapping("/name")
public class EnetRestController {

    private Logger logger=LoggerFactory.getLogger(EnetRestController.class);

    @Autowired
    EnetService enetservice;
    
    @RequestMapping(value = "/namechange",  method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity addName(@RequestBody NameChange namechange)
    {
    	//JSONObject jsonObject = new JSONObject();
    	 String res = enetservice.nameChange(namechange);
    	return new ResponseEntity(res, HttpStatus.CREATED);
    }
    
    @RequestMapping(value = "/panupdate",  method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity panupdate(@RequestBody PanUpdate panUpdate)
    {
    	//JSONObject jsonObject = new JSONObject();
    	 String res = enetservice.panUpdate(panUpdate);
    	return new ResponseEntity(res, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/addressUpdate",  method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity addressUpdate(@RequestBody Address addUpdate)
    {
    	//JSONObject jsonObject = new JSONObject();
    	 String res = enetservice.addressUpdate(addUpdate);
    	return new ResponseEntity(res, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/acks",  method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity acknowledgementStatus(@RequestBody Acknowledgement ack)
    {
    	//JSONObject jsonObject = new JSONObject();
    	 String res = enetservice.acknowledgement(ack);
    	return new ResponseEntity(res, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/kderdocmaster",  method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity kdrdocmaster(@RequestBody KdrDocMaster kdm)
    {
    	//JSONObject jsonObject = new JSONObject();
    	 String res = enetservice.kdrDoc(kdm);
    	return new ResponseEntity(res, HttpStatus.OK);
    }
}
