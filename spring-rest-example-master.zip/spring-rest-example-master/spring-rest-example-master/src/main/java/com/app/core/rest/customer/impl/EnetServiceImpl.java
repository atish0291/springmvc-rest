package com.app.core.rest.customer.impl;

import javax.inject.Named;

import com.app.core.rest.customer.model.Acknowledgement;
import com.app.core.rest.customer.model.Address;
import com.app.core.rest.customer.model.KdrDocMaster;
import com.app.core.rest.customer.model.NameChange;
import com.app.core.rest.customer.model.PanUpdate;
import com.app.core.rest.customer.service.EnetService;
import org.springframework.web.client.RestTemplate;

@Named("enetService")
public class EnetServiceImpl implements EnetService{
	
	RestTemplate restTemplate=new RestTemplate();

	@Override
	public String nameChange(NameChange name) {
		// TODO Auto-generated method stub
		// Build URL
        StringBuilder url = new StringBuilder().
                        append("https://hbretuatapp.hdfcbankuat.com/Enet_Service_UAT/Service1.svc/fnDataAndImage").
                        append("?name=" + name);
                       

        // Call service
        String result = restTemplate.getForObject(url.toString(), String.class);
        

        return result;
		
	}

	@Override
	public String panUpdate(PanUpdate pan) {
		// TODO Auto-generated method stub
		StringBuilder url = new StringBuilder().
                append("https://hbretuatapp.hdfcbankuat.com/Enet_Service_UAT/Service1.svc/fnDataAndImage").
                append("?pan=" + pan);
               
		
		// Call service
		String result = restTemplate.getForObject(url.toString(), String.class);
		
		
		return result;
	}

	@Override
	public String addressUpdate(Address address) {
		StringBuilder url = new StringBuilder().
                append("https://hbretuatapp.hdfcbankuat.com/Enet_Service_UAT/Service1.svc/fnDataAndImage").
                append("?address=" + address);
               
		
		// Call service
		String result = restTemplate.getForObject(url.toString(), String.class);
		
		
		return result;
	}

	@Override
	public String acknowledgement(Acknowledgement ack) {
		// TODO Auto-generated method stub
		StringBuilder url = new StringBuilder().
                append("https://hbretuatapp.hdfcbankuat.com/Enet_Service_UAT/Service1.svc/fnDataStatus").
				append("?ack=" + ack);
               
		
		// Call service
		String result = restTemplate.getForObject(url.toString(), String.class);
		
		
		return result;
	}

	@Override
	public String kdrDoc(KdrDocMaster kdm) {
		// TODO Auto-generated method stub
		StringBuilder url = new StringBuilder().
                append("https://hbretuatapp.hdfcbankuat.com/Enet_Service_UAT/Service1.svc/fnDocMaster").
				append("?kdm=" + kdm);
               
		
		// Call service
		String result = restTemplate.getForObject(url.toString(), String.class);
		
		
		return result;
	}

	 	//public NameChange getBook(long id);

	   
}
