package com.app.core.rest.customer.model;

public class Address {

}
