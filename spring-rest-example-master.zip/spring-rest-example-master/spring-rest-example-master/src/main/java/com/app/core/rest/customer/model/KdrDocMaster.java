package com.app.core.rest.customer.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KdrDocMaster {
	
private String Docmaster ;

public KdrDocMaster(@JsonProperty("Docmaster") String Docmaster) {
	super();
	this.Docmaster=Docmaster;
}
	
	public String getDocmaster() {
	return Docmaster;
}

public void setDocmaster(String docmaster) {
	Docmaster = docmaster;
}

	
}
