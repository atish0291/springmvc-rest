package com.app.core.rest.customer.model;

public class NameChangeResponse {
    public String AcknowledgementNo;

    public NameChangeResponse() {
    	this.AcknowledgementNo = "AcknowledgementNo";
    }

    public NameChangeResponse(String AcknowledgementNo) {
        this.AcknowledgementNo = AcknowledgementNo;
    }

    
}
