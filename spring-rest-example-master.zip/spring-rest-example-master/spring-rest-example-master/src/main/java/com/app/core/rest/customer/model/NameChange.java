package com.app.core.rest.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NameChange {
	
	private final String Barcode;
	private final String InstructionType;
	private final String City;
	private final String State;
	private final String Type;
	private final String AccountNumber;
	private final String AccountTitle;
	private final String LongAccountTitle;
	private final String CustID;
	private final String CustFullName;
	private List<TaggingDetails> TaggingDetails;
	

	public NameChange(@JsonProperty("Barcode") String Barcode, 
				  @JsonProperty("InstructionType") String InstructionType,
				  @JsonProperty("City") String City,
				  @JsonProperty("State") String State,
				  @JsonProperty("Type") String Type,
				  @JsonProperty("AccountNumber") String AccountNumber,
				  @JsonProperty("AccountTitle") String AccountTitle,
				  @JsonProperty("LongAccountTitle") String LongAccountTitle,
				  @JsonProperty("CustID") String CustID,
				  @JsonProperty("CustFullName") String CustFullName,
				  @JsonProperty("TaggingDetails") List<TaggingDetails> TaggingDetails) {
		super();
		this.Barcode = Barcode;
		this.InstructionType = InstructionType;
		this.City=City;
		this.State=State;
		this.Type = Type;
		this.AccountNumber=AccountNumber;
		this.AccountTitle=AccountTitle;
		this.LongAccountTitle=LongAccountTitle;
		this.CustID=CustID;
		this.CustFullName=CustFullName;
		this.TaggingDetails=TaggingDetails;
	}

	
	public String getCity() {
		return City;
	}


	public String getState() {
		return State;
	}


	public String getType() {
		return Type;
	}


	public String getAccountNumber() {
		return AccountNumber;
	}


	public String getAccountTitle() {
		return AccountTitle;
	}


	public String getLongAccountTitle() {
		return LongAccountTitle;
	}


	public String getCustID() {
		return CustID;
	}


	public String getCustFullName() {
		return CustFullName;
	}


	

	public List<TaggingDetails> getTaggingDetails() {
		return TaggingDetails;
	}


	public void setTaggingDetails(List<TaggingDetails> taggingDetails) {
		TaggingDetails = taggingDetails;
	}


	public String getInstructionType() {
		return InstructionType;
	}


	public String getBarcode() {
		return Barcode;
	}

	

}
