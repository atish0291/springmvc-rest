package com.app.core.rest.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PanUpdate {
	
	private final String Barcode;
	private final String InstructionType;
	private final String City;
	private final String State;
	private final String Type;
	
	private final String CustomerNameAsNSDL;
	private final String CustomerID;
	private final String CustomerFullName;
	private List<TaggingDetails> TaggingDetails;
	

	public PanUpdate(@JsonProperty("Barcode") String Barcode, 
				  @JsonProperty("InstructionType") String InstructionType,
				  @JsonProperty("City") String City,
				  @JsonProperty("State") String State,
				  @JsonProperty("Type") String Type,
				  @JsonProperty("CustomerNameAsNSDL") String CustomerNameAsNSDL,
				  @JsonProperty("CustomerID") String CustomerID,
				  @JsonProperty("CustomerFullName") String CustomerFullName,
				  @JsonProperty("TaggingDetails") List<TaggingDetails> TaggingDetails) {
		super();
		this.Barcode = Barcode;
		this.InstructionType = InstructionType;
		this.City=City;
		this.State=State;
		this.Type = Type;
		this.CustomerFullName=CustomerFullName;
		this.CustomerID=CustomerID;
		this.CustomerNameAsNSDL=CustomerNameAsNSDL;
		this.TaggingDetails=TaggingDetails;
	}


}
