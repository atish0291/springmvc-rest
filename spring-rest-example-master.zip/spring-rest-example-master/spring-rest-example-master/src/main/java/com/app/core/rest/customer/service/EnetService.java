package com.app.core.rest.customer.service;

import com.app.core.rest.customer.model.Acknowledgement;
import com.app.core.rest.customer.model.Address;
import com.app.core.rest.customer.model.KdrDocMaster;
import com.app.core.rest.customer.model.NameChange;
import com.app.core.rest.customer.model.PanUpdate;

public interface EnetService {

	 public String nameChange(NameChange name);

	 public String panUpdate(PanUpdate pan);
	 
	 public String addressUpdate(Address address);
	 
	 public String acknowledgement(Acknowledgement ack);
	 
	 public String kdrDoc(KdrDocMaster kdm);
}
