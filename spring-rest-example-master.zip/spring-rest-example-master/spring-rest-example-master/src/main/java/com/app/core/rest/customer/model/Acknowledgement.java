package com.app.core.rest.customer.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Acknowledgement {
	
	private final String AcknowledgementNo ;
	
	public Acknowledgement(@JsonProperty("AcknowledgementNo") String AcknowledgementNo) {
		super();
		this.AcknowledgementNo=AcknowledgementNo;
	}

	public String getAcknowledgementNo() {
		return AcknowledgementNo;
	}
	

}
